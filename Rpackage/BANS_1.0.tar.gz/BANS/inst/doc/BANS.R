### R code from vignette source 'BANS.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: PRECISE
###################################################
options(keep.source = TRUE, width = 60)
BANS <- packageDescription("BANS")


###################################################
### code chunk number 2: BANS.Rnw:27-28
###################################################
library(BANS)


###################################################
### code chunk number 3: BANS.Rnw:34-36
###################################################
data("TCGA_KIRC_CNA_mRNA_RPPA")
dim(mRNA);dim(RPPA)


###################################################
### code chunk number 4: BANS.Rnw:39-43
###################################################
Y = cbind(mRNA,RPPA)
colnames(Y) = c(paste("mRNA_",colnames(mRNA),sep="")
,paste("RPPA_",colnames(RPPA),sep=""))
dim(Y)


###################################################
### code chunk number 5: BANS.Rnw:46-48
###################################################
fit1 = ch.chaingraph(v.ch=1:10,v.pa=NULL,Y=Y,eta.prob=0.1
                    ,gamma.prob=0.1,lambda=5,delta=2,burnin.S=10,inf.S=20)


###################################################
### code chunk number 6: BANS.Rnw:51-53
###################################################
fit2 = ch.chaingraph(v.ch=11:24,v.pa=1:10,Y=Y,eta.prob=0.1
                    ,gamma.prob=0.1,lambda=5,delta=2,burnin.S=10,inf.S=20)


###################################################
### code chunk number 7: BANS.Rnw:56-58
###################################################
names(fit1)
names(fit2)


###################################################
### code chunk number 8: BANS.Rnw:63-69
###################################################
v=12
chlist = list(1:10,11:24)
palist = list(NULL,1:10)
vfit = v.chaingraph(v=v,chlist=chlist,palist=palist,Y=Y
                    ,lambda=5,delta=2,burnin.S=10,inf.S=20)
names(vfit)


###################################################
### code chunk number 9: BANS.Rnw:75-80
###################################################
p = ncol(Y)
B = matrix(0,p,p)
B[chlist[[1]],chlist[[1]]] = apply(fit1$eta,c(1,2),mean)
B[chlist[[2]],chlist[[2]]] = apply(fit2$eta,c(1,2),mean)
B[as.matrix(expand.grid(chlist[[1]],palist[[1]]))] = apply(fit2$Gamma,c(1,2),mean)


###################################################
### code chunk number 10: BANS.Rnw:83-90
###################################################
G = 1*(B>0.5)
t = 1 # first layer
sfit1 = ch.chaingraph.str(v.ch=chlist[[t]],v.pa=palist[[t]]
                          ,Y=Y,G=G,lambda=5,delta=2,burnin.S=10,inf.S=20)
t = 2 # second layer
sfit2 = ch.chaingraph.str(v.ch=chlist[[t]],v.pa=palist[[t]]
                          ,Y=Y,G=G,lambda=5,delta=2,burnin.S=10,inf.S=20)


